# Import Libriries 
import pandas as pd
import requests
from bs4 import BeautifulSoup
import os
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import cmudict

# Download necessary NLTK datasets
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('cmudict')


# Load positive and negative words  
# Load your list of positive words
positive_words = set('C:/Users/ARCHANA/Desktop/BLACKOFFER/positive-words.txt')  

# Load your list of negative words
negative_words = set('C:/Users/ARCHANA/Desktop/BLACKOFFER/negative-words.txt')  

# Load the dataset
input_file_path = r'C:\Users\ARCHANA\Desktop\BLACKOFFER\Input.xlsx'
data = pd.read_excel(input_file_path)

# Check if the data is loaded correctly
if data.empty:
    raise ValueError("The input data file is empty or could not be loaded.")

# Load the output data structure for analysis
output_structure_file_path = r'C:\Users\ARCHANA\Desktop\BLACKOFFER\Output Data Structure.xlsx'
output_structure = pd.read_excel(output_structure_file_path)

# Check if the output structure is loaded correctly
if output_structure.empty:
    raise ValueError("The output data structure file is empty or could not be loaded.")

# Directory where the extracted articles are saved
output_text_dir = r'C:/Users/ARCHANA/Desktop/BLACKOFFER/URL_ID.CSV'

os.makedirs(output_text_dir, exist_ok=True)

# Syllable dictionary from cmudict
d = cmudict.dict()

def count_syllables(word):
    if word.lower() in d:
        return max([len(list(y for y in x if y[-1].isdigit())) for x in d[word.lower()]])
    else:
        # Fallback: Estimate syllables by counting vowel groups
        return len(re.findall(r'[aeiouy]+', word.lower()))

def compute_complex_word(word):
    return count_syllables(word) >= 3

def perform_textual_analysis(text):
    # Tokenize text into words and sentences
    words = word_tokenize(text)
    sentences = sent_tokenize(text)

    # Filter out stopwords and non-alphabetic tokens
    words = [word for word in words if word.isalpha() and word.lower() not in stopwords.words('english')]

    # Calculate metrics
    positive_score = sum(1 for word in words if word.lower() in positive_words)
    negative_score = sum(1 for word in words if word.lower() in negative_words)
    polarity_score = (positive_score - negative_score) / (positive_score + negative_score + 0.000001)
    subjectivity_score = (positive_score + negative_score) / (len(words) + 0.000001)
    avg_sentence_length = len(words) / len(sentences)
    complex_words = sum(1 for word in words if compute_complex_word(word))
    percentage_complex_words = complex_words / len(words) * 100
    fog_index = 0.4 * (avg_sentence_length + percentage_complex_words)
    word_count = len(words)
    syllables_per_word = sum(count_syllables(word) for word in words) / len(words)
    personal_pronouns = len(re.findall(r'\b(I|we|my|ours|us)\b', text, re.I))
    avg_word_length = sum(len(word) for word in words) / len(words)
    
    return {
        'POSITIVE SCORE': positive_score,
        'NEGATIVE SCORE': negative_score,
        'POLARITY SCORE': polarity_score,
        'SUBJECTIVITY SCORE': subjectivity_score,
        'AVG SENTENCE LENGTH': avg_sentence_length,
        'PERCENTAGE OF COMPLEX WORDS': percentage_complex_words,
        'FOG INDEX': fog_index,
        'AVG NUMBER OF WORDS PER SENTENCE': avg_sentence_length,  # Same as avg_sentence_length
        'COMPLEX WORD COUNT': complex_words,
        'WORD COUNT': word_count,
        'SYLLABLE PER WORD': syllables_per_word,
        'PERSONAL PRONOUNS': personal_pronouns,
        'AVG WORD LENGTH': avg_word_length,
    }

# Create a DataFrame to store the analysis results
analysis_results_list = []

# Perform analysis on each extracted article
for index, row in data.iterrows():
    url_id = row['URL_ID']
    file_path = os.path.join(output_text_dir, f'{url_id}.txt')
    
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()
    
    analysis_results = perform_textual_analysis(text)
    analysis_results['URL_ID'] = url_id
    analysis_results_list.append(analysis_results)

# Convert the results list to a DataFrame
analysis_results_df = pd.DataFrame(analysis_results_list, columns=output_structure.columns)

# Save the analysis results to a CSV file
output_analysis_file_path = r'C:\Users\ARCHANA\Desktop\BLACKOFFER\result2.csv'
analysis_results_df.to_csv(output_analysis_file_path, index=False)

print(f"Textual analysis completed. The results have been saved to {output_analysis_file_path}")